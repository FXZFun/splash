import { WidgetHelper } from "../../modules/widget-helper.js";

export class QuickLinks {
    static load() {
        WidgetHelper.create(this, "Quick Links", "Shows your frequently accessed websites.");
    }

    async enable() {
        let hasPermissions = await chrome.permissions.contains({ permissions: ["favicon", "topSites"] });
        if (!hasPermissions) {
            let result = await chrome.permissions.request({ permissions: ["favicon", "topSites"] });
            if (!result) {
                WidgetHelper.setEnabled(this, false);
                WidgetHelper.destroyContainer(this)
                return false;
            }
        }

        WidgetHelper.addStyle(this);
        var container = WidgetHelper.getContainer(this);
        container.classList.add("gallery");
        container.style.display = "flex";
        container.innerHTML = "";

        chrome.topSites.get((sites) => {
            sites.forEach((site, index) => {
                if (index > 9) return;
                var div = document.createElement("div");
                div.classList.add("card");
                var a = document.createElement("a");
                a.href = site.url;
                div.appendChild(a);
                var img = document.createElement("img");
                img.src = "/_favicon/?pageUrl=" + site.url + "&size=64";
                a.appendChild(img);
                var p = document.createElement("p");
                p.innerText = site.title;
                a.appendChild(p);
                container.appendChild(div);
            })
        });
    }

    disable() {
        chrome.permissions.remove({ permissions: ["favicon", "topSites"] });
        WidgetHelper.destroyContainer(this);
    }
}