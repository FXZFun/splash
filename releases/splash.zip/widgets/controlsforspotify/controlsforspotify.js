import { WidgetHelper } from "../../modules/widget-helper.js";

class SpotifyApi {
    token;
    expiryDate;
    redirectUri = "chrome-extension://" + chrome.runtime.id + "/widgets/controlsforspotify/connected.html";
    state = this.randomString(16);
    scopes = "user-modify-playback-state user-read-playback-state";
    #CLIENT_ID = "a5f41f084ec8406abdfaed90900be7fa";
    #CLIENT_SECRET = "6cf83a06f4814c8a900ae2a3f65e67c7";
    code;

    constructor() {
        this.token = localStorage.getItem("controls-for-spotify-token") ?? "";
        this.expiryDate =
            new Date(localStorage.getItem("controls-for-spotify-date")) ??
            new Date();
    }

    isExpired() {
        return new Date().getTime() - this.expiryDate.getTime() > 0;
    }

    getToken() {
        return this.token;
    }

    requestToken(code) {
        this.code = code;
        const url = "https://accounts.spotify.com/api/token";
        fetch(url, {
            method: "POST",
            headers: { "Content-Type": "application/x-www-form-urlencoded" },
            body: `grant_type=authorization_code&code=${code}&redirect_uri=${this.redirectUri}&client_id=${this.#CLIENT_ID}&client_secret=${this.#CLIENT_SECRET}`
        }).then(r => {
            r.json().then(json => {
                this.token = json["access_token"];
                this.expiryDate = new Date(
                    new Date().getTime() + json["expires_in"] * 1000
                );
                localStorage.setItem("controls-for-spotify-token", this.token);
                localStorage.setItem(
                    "controls-for-spotify-date",
                    this.expiryDate.getTime()
                );
                setTimeout(() => {
                    this.requestToken(code);
                }, json["expires_in"] * 1000);
            });
        });
    }

    getUserPermission() {
        var tab = window.open(
            "https://accounts.spotify.com/authorize?response_type=code&client_id=" +
            this.#CLIENT_ID +
            "&scope=" +
            this.scopes +
            "&redirect_uri=" +
            this.redirectUri +
            "&state=" +
            this.state
        );
        var bootstrap = setInterval(() => {
            if (!tab.location.href) clearInterval(bootstrap);
            if (tab.location.href?.startsWith("chrome-extension://")) {
                clearInterval(bootstrap);
                var params = new URLSearchParams(tab.location.search);
                this.requestToken(params.get("code"));
                tab.close();
            }
        }, 250);
    }

    randomString(length) {
        var chars = "qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM0123456789".split(
            ""
        );
        var text = "";
        for (var i = 0; i < length; i++) {
            text += chars[Math.floor(Math.random() * chars.length)];
        }
        return text;
    }

    lastSong() {
        fetch("https://api.spotify.com/v1/me/player/previous", {
            method: "POST",
            headers: {
                "Content-Type": "application/x-www-form-urlencoded",
                Authorization: "Bearer " + this.token
            }
        });
    }

    playMusic() {
        fetch("https://api.spotify.com/v1/me/player/play", {
            method: "PUT",
            headers: {
                "Content-Type": "application/x-www-form-urlencoded",
                Authorization: "Bearer " + this.token
            }
        });
    }

    pauseMusic() {
        fetch("https://api.spotify.com/v1/me/player/pause", {
            method: "PUT",
            headers: {
                "Content-Type": "application/x-www-form-urlencoded",
                Authorization: "Bearer " + this.token
            }
        });
    }

    nextSong() {
        fetch("https://api.spotify.com/v1/me/player/next", {
            method: "POST",
            headers: {
                "Content-Type": "application/x-www-form-urlencoded",
                Authorization: "Bearer " + this.token
            }
        });
    }

    async getState() {
        const result = await fetch("https://api.spotify.com/v1/me/player", {
            method: "GET",
            headers: {
                "Content-Type": "application/x-www-form-urlencoded",
                Authorization: "Bearer " + this.token
            }
        });
        const json = await result.json();
        return json.is_playing;
    }

    async toggleMusic() {
        await this.getState() ? this.pauseMusic() : this.playMusic()
    }
}

const spotifyApi = new SpotifyApi();

export class ControlsForSpotify {
    static load() {
        WidgetHelper.create(this, "Controls for Spotify", "Adds controls for Spotify to your home screen! (please note however, this may not work with your Spotify account yet.) Requires Spotify Premium.");
    }

    enable() {
        WidgetHelper.getContainer(this).innerHTML = `<button id="spotify-back"><i class="material-icons">skip_previous</i></button><button id="spotify-pp"><i class="material-icons">music_note</i></button><button id="spotify-next"><i class="material-icons">skip_next</i></button>`;
        WidgetHelper.getSettingsContainer(this).innerHTML = `<button class="spotify-button">Login with Spotify</button>`;
        document.querySelector(".spotify-button").onclick = () => {
            spotifyApi.getUserPermission();
        };
        document.getElementById("spotify-back").onclick = () => {
            spotifyApi.lastSong();
        };
        document.getElementById("spotify-pp").onclick = () => {
            spotifyApi.toggleMusic();
        };
        document.getElementById("spotify-next").onclick = () => {
            spotifyApi.nextSong();
        };
        WidgetHelper.addStyle(this);
    }

    disable() {
        WidgetHelper.destroyContainer(this);
    }
}