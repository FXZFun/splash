export class Autocomplete {
    sessiontoken = "";
    input;
    #APIKEY = "AIzaSyDuDBm96B82JKMvrKPy1GHuGCRavIXiuLs";
    autoCompleteBox;
    keyIndex = 2;
    constructor() {
        this.sessiontoken = this.newSessionToken();
        this.keyIndex = 2;
    }

    newSessionToken() {
        var chars = "QWERTYUIOPASDFGHJKLZXCVBNMqwertyuiopasdfghjklzxcvbnm".split("");
        var length = 30;
        var token = "";
        for (var i = 0; i < length; i++) {
            token += chars[Math.floor(Math.random() * chars.length)];
        }
        return token;
    }

    bind(input) {
        this.input = input;
        this.onkeyup = this.onkeyup.bind(this);
        this.input.onkeyup = this.onkeyup;
        this.addAutoCompleteBox();
    }

    onkeyup() {
        if (this.keyIndex == 2) {
            this.autoComplete(this.input.value);
            this.keyIndex = 0;
        } else {
            this.keyIndex++;
        }
    }

    async autoComplete(input) {
        if (this.sessiontoken.trim() == "") {
            this.sessiontoken = this.newSessionToken();
        }
        var fetchObj = await fetch("https://maps.googleapis.com/maps/api/place/autocomplete/json?key=" + this.#APIKEY + "&input=" + input + "&sessiontoken=" + this.sessiontoken, { "method": "GET", "headers": {} });
        var json = await fetchObj.json();
        this.autoCompleteBox.innerHTML = "";
        json.predictions.forEach(prediction => {
            this.addItem(prediction.place_id, prediction.structured_formatting.main_text, prediction.structured_formatting.hasOwnProperty("secondary_text") ? prediction.structured_formatting.secondary_text : "");
        });
        var img = document.createElement("img");
        img.src = "/imgs/google_on_white_hdpi.png";
        this.autoCompleteBox.appendChild(img);
    }

    addItem(placeId, bigText, smallText) {
        var div = document.createElement("div");
        div.dataset.placeId = placeId;
        div.innerHTML = `<p class="autocomplete-place" data-place-id="${placeId}"><span data-place-id="${placeId}">${bigText}</span> <span class="grayText" data-place-id="${placeId}">${smallText}</span></p>`;
        this.onClicked = this.onClicked.bind(this);
        div.onclick = this.onClicked;
        this.autoCompleteBox.appendChild(div);
    }

    onClicked(ev) {
        let el = ev.target;
        this.placeSelected(el.dataset.placeId);
    }

    addAutoCompleteBox() {
        this.autoCompleteBox = document.createElement("div");
        this.autoCompleteBox.style.position = "absolute";
        this.autoCompleteBox.style.top = this.input.clientHeight + this.input.clientTop + 10 + "px";
        this.autoCompleteBox.style.width = this.input.clientWidth + "px";
        this.autoCompleteBox.classList.add("autocompleteBox");
        this.autoCompleteBox.innerHTML = "";
        this.autoCompleteBox.style.display = "none";
        // document.body.appendChild(this.autoCompleteBox);
        this.input.insertAdjacentElement("afterEnd", this.autoCompleteBox);
        this.hideAutocompleteBox = this.hideAutocompleteBox.bind(this);
        this.showAutocompleteBox = this.showAutocompleteBox.bind(this);
        this.input.onblur = this.hideAutocompleteBox;
        this.input.onfocus = this.showAutocompleteBox;
    }

    hideAutocompleteBox() {
        setTimeout(() => {
            this.autoCompleteBox.style.display = "none";
        }, 100);
    }
    showAutocompleteBox() {
        this.autoCompleteBox.style.display = "block";
    }

    async placeSelected(placeId) {
        var fetchObj = await fetch("https://maps.googleapis.com/maps/api/place/details/json?place_id=" + placeId + "&key=" + this.#APIKEY + "&sessiontoken=" + this.sessiontoken, { "method": "GET", "headers": {} });
        var json = await fetchObj.json();
        if (typeof this.callback == 'function') {
            this.callback(json);
        }

        // make a new session token for next requests;
        this.sessiontoken = this.newSessionToken();
    }

    setOnCompleteListener(callback) {
        this.callback = callback;
    }
}