turf.point = turf.helpers.point;
turf.featureCollection = turf.helpers.featureCollection;

function cToF(celsius) {
    return Math.round(celsius * 1.8 + 32);
}

function getWeather() {
    var gridY = localStorage.getItem("gridY");
    var gridX = localStorage.getItem("gridX");
    var gridId = localStorage.getItem("gridId");
    var forecastZone = localStorage.getItem("forecastZone");
    fetch(`https://api.weather.gov/gridpoints/${gridId}/${gridX},${gridY}/forecast`).then(function (j) {
        j.json().then(function (t) {
            if (!t["properties"]["periods"][0]["isDaytime"]) {
                document.getElementById("low").innerText = "Low: " + t["properties"]["periods"][0]["temperature"] + "°F";
            } else {
                document.getElementById("low").innerText = "High: " + t["properties"]["periods"][0]["temperature"] + "°F";
                document.getElementById("low").classList.remove("low");
                document.getElementById("low").classList.add("high");
            }
            document.getElementById("lowImage").src = t["properties"]["periods"][0]["icon"];
            document.getElementById("lowTitle").innerText = t["properties"]["periods"][0]["name"];
            document.getElementById("lowShortName").innerText = t["properties"]["periods"][0]["shortForecast"];
        });
    });
    fetch(`${forecastZone}/observations`).then(function (j) {
        j.json().then(function (t) {
            var foundOne = false;
            t["features"].forEach(f => {
                if (f["properties"]["temperature"]["value"] != null && !foundOne) {
                    foundOne = true;
                    if (f["properties"]["temperature"]["unitCode"] == "wmoUnit:degC") {
                        document.getElementById("high").innerText = cToF(f["properties"]["temperature"]["value"]) + "°F";
                    } else {
                        document.getElementById("high").innerText = f["properties"]["temperature"]["value"] + "°F";
                    }
                    document.getElementById("highImage").src = f["properties"]["icon"];
                    document.getElementById("highShortName").innerText = f["properties"]["textDescription"];
                }
            });
        });
    });
}

getWeather();

function changePlace() {
    document.querySelector(".modal").style.display = "block";
    document.querySelector("#map").style.display = "block";
}

function finishChange() {
    let markerPosition = marker.getPosition();
    localStorage.setItem("lat", markerPosition.lat());
    localStorage.setItem("lon", markerPosition.lng());
    document.querySelector(".modal").style.display = "none";
    document.querySelector("#map").style.display = "none";
    fetch(`https://api.weather.gov/points/${markerPosition.lat()},${markerPosition.lng()}`).then(function (j) {
        j.json().then(function (t) {
            localStorage.setItem("gridId", t["properties"]["cwa"])
            localStorage.setItem("gridX", t["properties"]["gridX"])
            localStorage.setItem("gridY", t["properties"]["gridY"])
            localStorage.setItem("forecastZone", t["properties"]["forecastZone"])
            localStorage.setItem("placeName", t["properties"]["relativeLocation"]["properties"]["city"] + ", " + t["properties"]["relativeLocation"]["properties"]["state"])
        });
        location.reload();
    });
}
if (navigator.onLine) {
    setTimeout(() => {
        document.getElementById("placeName").onclick = changePlace;
        document.getElementById("doneBtn").onclick = finishChange;
        let script = document.createElement('script');
        script.src = "https://maps.googleapis.com/maps/api/js?key=AIzaSyDuDBm96B82JKMvrKPy1GHuGCRavIXiuLs&callback=initMap";
        script.async = true;
        script.defer = true;
        document.body.appendChild(script);
        document.getElementById("placeName").innerText = localStorage.getItem("placeName");
        if (localStorage.hasOwnProperty("calendar")) {
            document.getElementById("calendarPlace").src = localStorage.getItem("calendar");
        }
    }, 100);
}

var inpopup = false;
setTimeout(() => {
    var params = new URLSearchParams(location.search);
    if (params.has("popup")) {
        document.body.style.height = "600px";
        document.body.style.width = "400px";
        document.body.classList.add("inpopup");
        document.getElementById("weatherSpot").classList.add("active");
        document.getElementById("weatherBtn").onclick = () => {
            toggleActiveSpot("weather");
        }
        document.getElementById("bookmarksBtn").onclick = () => {
            toggleActiveSpot("bookmarks");
        }
        document.getElementById("calendarBtn").onclick = () => {
            toggleActiveSpot("calendar");
        }
        inpopup = true;
    }
}, 200);

function toggleActiveSpot(newspot = "weather") {
    document.querySelector(".spot.active").classList.remove("active");
    document.querySelector(".btnStripBtn.active").classList.remove("active");
    document.querySelector("#" + newspot + "Spot").classList.add("active");
    document.querySelector("#" + newspot + "Btn").classList.add("active");
}
function initMap() {
    var currentLL = {
        lat: parseFloat(localStorage.getItem("lat") ? localStorage.getItem("lat") : 40.7128),
        lng: parseFloat(localStorage.getItem("lon") ? localStorage.getItem("lon") : -74.0060)
    };

    var map = new google.maps.Map(document.getElementById('map'), {
        zoom: 4,
        center: {
            lat: 40.41388815007207,
            lng: -95.89502334594727
        }
    });

    marker = new google.maps.Marker({
        position: currentLL,
        map: map,
        draggable: true
    });
}

function getGridFromLocation(lat, lng) {
    return new Promise((resolve, reject) => {
        fetch(`https://api.weather.gov/points/${lat},${lng}`).then(function (response) {
            response.json().then(function (json) {
                localStorage.setItem("gridId", t["properties"]["cwa"])
                localStorage.setItem("gridX", t["properties"]["gridX"])
                localStorage.setItem("gridY", t["properties"]["gridY"])
                localStorage.setItem("forecastZone", t["properties"]["forecastZone"])
                localStorage.setItem("placeName", t["properties"]["relativeLocation"]["properties"]["city"] + ", " + t["properties"]["relativeLocation"]["properties"]["state"])
            });
            location.reload();
        });
    });
}

export async function getClosestStationId(state, lat, lng) {
    let response = await fetch(`https://api.weather.gov/stations?state=${state}&limit=500`);
    if (!response.ok) return null;

    let json = await response.json();
    let points = json?.features?.map(f => new turf.point(f?.geometry?.coordinates));
    
    let nearest = turf.nearestPoint(turf.point([lng, lat]), turf.featureCollection(points));
    let station = json?.features?.find(f => f.geometry.coordinates[0] === nearest.geometry.coordinates[0] && f.geometry.coordinates[1] === nearest.geometry.coordinates[1]);

    return station?.properties?.stationIdentifier;
}

async function getWeatherFromStation(stationId) {
    let response = await fetch(`https://api.weather.gov/stations/${stationId}/observations/latest`);
    let json = await response.json();


    nearestPoint(new point())
}

function saveGrid(gridId, gridX, gridY, forecastZone) {

}